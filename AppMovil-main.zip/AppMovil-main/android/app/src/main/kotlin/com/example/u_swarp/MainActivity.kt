package com.example.u_swarp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
